Ian M. Schmutte
schmutte@uga.edu
17 January 2017

This folder contains results as they were released from the Federal Statistical Research Data Center with accompanying disclosure avoidance review memoranda.