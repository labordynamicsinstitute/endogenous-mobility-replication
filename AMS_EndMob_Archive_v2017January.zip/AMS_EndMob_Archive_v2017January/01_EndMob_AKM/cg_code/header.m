% Matlab header

% /*working path*/
	% /*working path*/
	wrk_path = '$TEMP/interwork/abowd001/networks/outputs/';
	% /*output data path */
	out_path = '$TEMP/interwork/abowd001/networks/outputs/';