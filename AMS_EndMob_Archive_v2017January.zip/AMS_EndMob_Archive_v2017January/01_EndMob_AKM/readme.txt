Code to estimate AKM on 3-state sample for years 1999--2003 for JBES revision
Drafted February 16, 2016
Ian M. Schmutte

Sequence:
	./dataprep/
		./01.01.AKM_Universe.sas
		./01.02.prep_for_CG.sas
	./CG_Code
		./s01_CG_load_data.m
		./s02_CG_est_JBES.m